//package telephoneDirectory;
//import java.io.*;
//import java.util.Scanner;
//import models.Contact;
//
//
//
//public class TelephoneDirectory {
//    static int Max_count;
//    static int entryCount;
//    static Contact[] directory;
//    static Scanner scanner = new Scanner(System.in);
//
//    private static void createArrayContact() {
//        System.out.println("Enter length of contact folder:");
//        Max_count = Integer.parseInt(scanner.nextLine());
//        entryCount = 0;
//        directory = new Contact[Max_count];
//        if (entryCount < Max_count) {
//            for (int i = 0; i < Max_count; i++) {
//                Contact newContact = new Contact();
//                System.out.print("Enter name: \n");
//                newContact.name = scanner.nextLine();
//                System.out.print("Enter age: \n");
//                newContact.age = Integer.parseInt(scanner.nextLine());
//                System.out.print("Enter contact number: \n");
//                newContact.number = scanner.nextLine();
//
//                directory[entryCount] = newContact;
//                entryCount++;
//            }
//        }
//    }
//    private static void saveToAFile() {
//        if (entryCount != 0 || directory != null) {
//            try {
//                BufferedWriter writer = new BufferedWriter(new FileWriter("contacts.txt"));
//                for (int i = 0; i < entryCount; i++) {
//                    writer.write(directory[i].toString());
//                    writer.newLine();
//                }System.out.println("Contact(s) saved to Contact book😃");
//            }catch (IOException e) {
//                System.out.println("Error saving to file: " + e.getMessage());
//            }
//        }else {
//            System.out.println("No contacts data to be saved☹❌");
//        }
//    }
//
//    private static void retrieveDataByIndex() {
//        if (entryCount == 0 || directory == null) {
//            System.out.println("No contact to display☹❌");
//        } else {
//            System.out.println("Enter index number of contact");
//            int index = Integer.parseInt(scanner.nextLine());
//            if (index >= 0 && index <= entryCount) {
//                System.out.println(directory[index]);
//            }
//        }
//    }
//
//
//    private static void displayRange() {
//        if (entryCount == 0 || directory == null) {
//            System.out.println("No contact to display☹❌");
//        }else {
//            System.out.println("Enter starting point: ");
//            int startIndex = Integer.parseInt(scanner.nextLine());
//            System.out.println("Enter ending point: ");
//            int endIndex = Integer.parseInt(scanner.nextLine());
//            if (startIndex >=0 && endIndex <= entryCount && startIndex <= endIndex) {
//                for (int i = startIndex; i < endIndex; i++) {
//                    System.out.println(directory[i]);
//                }
//            }else {
//                System.out.println("Enter within range of array");
//            }
//        }
//    }
//   private static void displayEntries() {
//        if (entryCount == 0 || directory == null) {
//            System.out.println("No contact to display☹❌");
//        }else {
//            System.out.println("Contacts saved to Contact book:");
//            for (int i = 0; i < entryCount; i++) {
//                System.out.println("Contact " + (i+1) + ": ");
//                System.out.println("Name: " + directory[i].name);
//                System.out.println("Age: " + directory[i].age);
//                System.out.println("Phone-number " + directory[i].number);
//                System.out.println();
//            }
//        }
//    }
//
//    private static void displaySpecChar() {
//        if (entryCount == 0 || directory == null){
//            System.out.println("No contact to display☹❌");
//        }else {
//            boolean found = false;
//            System.out.println("Enter starting character of contact");
//            char ch = scanner.next().charAt(0);
//            for (int i = 0; i < entryCount; i++) {
//                if (directory[i].name.startsWith(String.valueOf(ch))); {
//                    System.out.println(directory[i]);
//                    found = true;
//                }
//            }if (!found) {
//                System.out.println("Your entry was not found☹");
//            }
//        }
//    }
//
//    private static void deleteContact() {
//        if (entryCount == 0 || directory == null) {
//            System.out.println("No contact to display☹❌");
//        }else {
//            boolean found = false;
//            System.out.println("Enter contact name to delete");
//            String str = scanner.nextLine();
//            for (int i = 0; i < entryCount; i++) {
//                if (directory[i].name.equalsIgnoreCase(str)) {
//                    found = true;
//                    for (int j = i; j < entryCount-1; j++) {
//                        directory[j] = directory[j + 1];
//                    }
//                    directory[entryCount - 1] = null;
//                    entryCount --;
//                    break;
//                }
//            }if (!found) {System.out.println("Your entry was not found☹");}
//        }
//    }
//
//        public static void main(String[] args) {
//            int choice;
//
//            do {
//
//                System.out.println("\n--- Telephone Directory Menu ---");
//                System.out.println("1. Create an array to save contact details");
//                System.out.println("2. Save data to a file");
//                System.out.println("3. Retrieve data by index");
//                System.out.println("4. Display data in a range");
//                System.out.println("5. Display all entries");
//                System.out.println("6. Display entries starting with a specific character");
//                System.out.println("7. Delete a contact");
//                System.out.println("8. Exit");
//                System.out.print("Choose an option: ");
//
//                choice = Integer.parseInt(scanner.nextLine());
//
//                switch (choice) {
//                    case 1:
//                        createArrayContact();
//                        break;
//                    case 2:
//                        saveToAFile();
//                        break;
//                    case 3:
//                        retrieveDataByIndex();
//                        break;
//                    case 4:
//                        displayRange();
//                        break;
//                    case 5:
//                        displayEntries();
//                        break;
//                    case 6:
//                        displaySpecChar();
//                        break;
//                    case 7:
//                        deleteContact();
//                        break;
//                    case 8:
//                        System.out.println("Exiting by request...");
//                        break;
//                    default:
//                        System.out.println("Invalid entry");
//
//                }
//            }while (choice != 8);
//        }
//    }


package telephoneDirectory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import models.Contact;

public class TelephoneDirectory {
    //    static int Max_count;
//    static int entryCount;
//    static Contact[] directory;
    static List<Contact> directory = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    private static void createArrayContact() {
        System.out.println("\n--- Create Contact Array ---");
        try {
            System.out.print("Enter number of contacts to add: ");
            int numOfContacts = Integer.parseInt(scanner.nextLine());
//            Max_count = Integer.parseInt(scanner.nextLine());
//            entryCount = 0;
//            directory = new Contact[Max_count];

            for (int i = 0; i < numOfContacts; i++) {
                System.out.printf("\n--- Adding Contact %d ---\n", i + 1);
                Contact newContact = new Contact();
                System.out.print("Enter Name: ");
                newContact.name = scanner.nextLine();
                System.out.print("Enter Age: ");
                newContact.age = Integer.parseInt(scanner.nextLine());
                System.out.print("Enter Phone Number: ");
                newContact.number = scanner.nextLine();

//                directory[entryCount] = newContact;
//                entryCount++;
                directory.add(newContact);
                System.out.println("Contact successfully added! 🎉");
            }
        } catch (Exception e) {
            System.out.println("Invalid input! Please start again.");
        }
    }

    private static void saveToAFile() {
        System.out.println("\n--- Save Contacts to File ---");
//        if (entryCount > 0 && directory != null) {
        if (!directory.isEmpty()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("contacts.txt"))) {
//                for (int i = 0; i < entryCount; i++) {
                for (Contact contact : directory) {
                    writer.write(contact.name + ", " + contact.age + ", " + contact.number);
//                    writer.write(directory[i].toString());
                    writer.newLine();
                }
                System.out.println("Contacts saved successfully! ✅");
            } catch (IOException e) {
                System.out.println("Error saving to file: " + e.getMessage());
            }
        } else {
            System.out.println("No contacts to save. Add some first!");
        }
    }

    private static void retrieveDataByIndex() {
        System.out.println("\n--- Retrieve Contact by Index ---");
//        if (entryCount == 0 || directory == null) {
        if (directory.isEmpty()) {
            System.out.println("No contacts available!");
            return;
        }

        try {
            System.out.print("Enter the index (starting from 0): ");
            int index = Integer.parseInt(scanner.nextLine());
//            if (index >= 0 && index < entryCount) {
            if (index >= 0 && index < directory.size()) {
                System.out.println("Contact Details:");
//                System.out.println(directory[index]);
                System.out.println(directory.get(index));
            } else {
                System.out.println("Invalid index. Please try again.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input! Please enter a valid index.");
        }
    }

    private static void displayRange() {
        System.out.println("\n--- Display Contacts in a Range ---");
//        if (entryCount == 0 || directory == null) {
        if (directory.isEmpty()) {
            System.out.println("No contacts available!");
            return;
        }

        try {
            System.out.print("Enter starting index: ");
            int startIndex = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter ending index: ");
            int endIndex = Integer.parseInt(scanner.nextLine());

//            if (startIndex >= 0 && endIndex <= entryCount && startIndex <= endIndex) {
            if (startIndex >= 0 && endIndex < directory.size() && startIndex <= endIndex) {
                System.out.println("Contacts in the specified range:");
                for (int i = startIndex; i <= endIndex; i++) {
//                    System.out.println(directory[i]);
                    System.out.println(directory.get(i));
                }
            } else {
                System.out.println("Invalid range! Please try again.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input! Please enter valid indices.");
        }
    }

    private static void displayEntries() {
        System.out.println("\n--- Display All Contacts ---");
//        if (entryCount == 0 || directory == null) {
        if (directory.isEmpty()) {
            System.out.println("No contacts to display!");
        } else {
//            for (int i = 0; i < entryCount; i++) {
            for (int i = 0; i < directory.size(); i++) {
//                System.out.println("Contact " + (i + 1) + ":");
//                System.out.println("  Name: " + directory[i].name);
//                System.out.println("  Age: " + directory[i].age);
//                System.out.println("  Phone: " + directory[i].number);
//                System.out.println();
                System.out.println("Contact " + (i + 1) + ":");
                System.out.println("  Name: " + directory.get(i).name);
                System.out.println("  Age: " + directory.get(i).age);
                System.out.println("  Phone: " + directory.get(i).number);
                System.out.println();
//                loadFromFile();
            }
        }
    }

    private static void deleteContact() {
        System.out.println("\n--- Delete a Contact ---");
//        if (entryCount == 0 || directory == null) {
        if (directory.isEmpty()){
            System.out.println("No contacts to delete!");
            return;
        }

        try {
            System.out.print("Enter the name of the contact to delete: ");
            String nameToDelete = scanner.nextLine();
            boolean found = false;

//            for (int i = 0; i < entryCount; i++) {

//                if (directory[i].name.equalsIgnoreCase(nameToDelete)) {
                for (int i = 0; i < directory.size(); i++){
                if (directory.get(i).name.equalsIgnoreCase(nameToDelete)){
                    directory.remove(i);
                    System.out.println("Contact deleted successfully!");
                    found = true;
//                    for (int j = i; j < entryCount - 1; j++) {
//                    for (int j = i; j < directory.size(); i++){
//                        directory[j] = directory[j + 1];
//                    }
//                    directory[entryCount - 1] = null;
//                    entryCount--;
//                    System.out.println("Contact deleted successfully!");
                    break;
                }
            }

            if (!found) {
                System.out.println("Contact not found!");
            }
        } catch (Exception e) {
            System.out.println("An error occurred while deleting the contact.");
        }
    }

    public static void main(String[] args) {



        int choice;


        do {
            System.out.println("\n--- Telephone Directory Menu ---");
            System.out.println("1. Create Contact Array");
            System.out.println("2. Save Contacts to File");
            System.out.println("3. Retrieve Contact by Index");
            System.out.println("4. Display Contacts in a Range");
            System.out.println("5. Display All Contacts");
            System.out.println("6. Delete a Contact");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1 -> createArrayContact();
                    case 2 -> saveToAFile();
                    case 3 -> retrieveDataByIndex();
                    case 4 -> displayRange();
                    case 5 -> displayEntries();
                    case 6 -> deleteContact();
                    case 7 -> System.out.println("Exiting application... Goodbye!");
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input! Please choose a valid option.");
                choice = 0; // Loop back to the menu
            }
        } while (choice != 7);

        loadFromFile();
    }



        public static void loadFromFile () {
        try (BufferedReader reader = new BufferedReader(new FileReader("contacts.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(","); // Assuming the data is separated by comma
                Contact contact = new Contact();
                contact.name = parts[0];
                contact.age = Integer.parseInt(parts[1]);
                contact.number = parts[2];
                directory.add(contact);

            }
            System.out.println("Contacts loaded successfully!");

        } catch (IOException e) {
            System.out.println("No previous contacts found or an error occurred when loading the file");
        }
    }

    }


