package models;

public class Contact {
    public String name;
    public int age;
    public String number;


    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age + ", Contact: " + number;
    }
}
